OpenFM Stream Kit\n-------------------\nContains placeholder assets for overlays and sponsor loops. Replace with final creative before shipping.
